LUXE HAIR STUDIO — COMPILED SITE
This ZIP is the production build, exactly as served. It is static & self-contained.

TO DEPLOY: unzip, upload the contents of 'luxe-hair-studio-site' to any static host
(Netlify, Vercel, S3, cPanel) at the DOMAIN ROOT, or run `npx serve` in the folder.

NOTE: do not open index.html by double-clicking — browsers block ES-module apps
from file://. Serve it over http (npx serve / python3 -m http.server 4173).